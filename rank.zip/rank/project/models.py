from django.db import models
from django.contrib.auth.models import User


class UserProfile(models.Model):
    firstname = models.CharField(max_length=30)
    lastname = models.CharField(max_length=30)
    description = models.CharField(max_length=500)
    #username = models.ForeignKey(User, on_delete=models.CASCADE,default='00')
    #user = models.OneToOneField(User, on_delete=models.PROTECT,default='00')
    email = models.EmailField(
        verbose_name='email address',
        max_length=255,
        unique=True, 
        primary_key=True,
    )
    address1 = models.CharField(max_length=100,default='USA')
    address2 = models.CharField(max_length=100,blank=True)
    city = models.CharField(max_length=50,blank=True)
    region = models.CharField(max_length=50,blank=True)
    zipcode = models.CharField(max_length=10,blank=True)
    country = models.CharField(max_length=20,blank=True)
    linkedln = models.CharField(max_length=100,blank=True)
    github = models.CharField(max_length=50,blank=True)
    otherlink = models.CharField(max_length=50,blank=True)
    resume = models.FileField(upload_to='Resume/',blank=True)
    picture = models.ImageField(upload_to='Picture/', blank=True)

class Project(models.Model):
    email = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
    projectname = models.CharField(max_length=100, default='Data Analytics project')
    types = (
        ('e', 'Data Cleaning / EDA'),
        ('p', 'Predictive Analysis'),
        ('d', 'Descriptive Analysis / Data Visualization'),    
    )
    projecttype = models.CharField(
        max_length=1,
        choices=types,
        blank=True,
        default='e',
        help_text='Project Type',
    )
    description = models.CharField(max_length=1000, default='Data Analytics project')
    result = models.CharField(max_length=1000, default='Data Analytics project')   
    pub_date = models.DateTimeField('date published')