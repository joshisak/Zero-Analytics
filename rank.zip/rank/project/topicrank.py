# -*- coding: utf-8 -*-

#  finding most important para from all the paragraphs of all files clubbed together into
#  one array
"""
Created on Fri 6th March 2020

@author: Sakshi
"""

import os
from sklearn.feature_extraction.text import TfidfVectorizer
#from sklearn.feature_extraction.text import CountVectorizer
import networkx as nx
import re
from docx import Document
import PyPDF2
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import string
from nltk.tokenize import word_tokenize


def return_content(keywords,file):
    query_vocabulary = keywords.split(',')
    filename = os.path.join("C:\\Users\\saksh\\Desktop\\Projects\\ZA\\rank\\repository",file)
    def ranker(content_index,content,query_vocabulary):
        vectorizer = TfidfVectorizer()
        #vectorizer = CountVectorizer()
        vectorizer.fit(query_vocabulary)
        #vectorizer.get_feature_names()
        bow_matrix = vectorizer.transform(content)
        #print(bow_matrix.toarray())
        normalized_matrix=bow_matrix
        similarity_graph = normalized_matrix * normalized_matrix.T
        #similarity_graph.toarray()
        nx_graph = nx.from_scipy_sparse_matrix(similarity_graph)
        scores = nx.pagerank(nx_graph)
        score_values=(list(scores.values()))
        ranked = sorted(((score_values[i],s) for i,s in enumerate(content_index)),reverse=True)
        return(ranked)
    
#populate an array
    content=[]

    if re.search(r'\w*.txt',file):
        data=open(filename,'r')
        doc=data.read()
        array_of_para =re.split('\n1|\n\n|\n[0-9].|\n[0-9][0-9].|\n¦ \n' ,doc)
        content.extend(array_of_para)
    elif re.search(r'\w*.doc',file):
        doc = Document(filename)
        for docpara in doc.paragraphs:
            content.append(docpara.text)
    elif re.search(r'\w*.pdf',file):
        file = open(filename, 'rb')
        fileReader = PyPDF2.PdfFileReader(file)
        for page in range(fileReader.numPages):
            pg = fileReader.getPage(page)
            text = pg.extractText()
            text = re.sub('[^A-Za-z0-9. ]+', '', text)
            content.append(text)
    
    #prepocessing the content
    commonwords = set(stopwords.words('english'))
    exclude = set(string.punctuation) 
    lemma = WordNetLemmatizer()
    dataset=[]
    for para in content:
        if len(para)==0:
            content.remove(para)
        punc_free = ''.join(ch for ch in para if ch not in exclude)
        token = word_tokenize(punc_free.lower())
        lemmatized = [lemma.lemmatize(x) for x in token]
        text = [x for x in lemmatized if x not in commonwords]
        normalized = " ".join(text)
        dataset.append(normalized)

    content_index=list(range(0,len(content)))
    paragraph_ranked=ranker(content_index,dataset, query_vocabulary)

  
# printing relevant para and filename based on search done on meta-data matching with the query
    output = []
    for i in range(0,len(content)):
        p=paragraph_ranked[i][1]
        score = round(paragraph_ranked[i][0]*100, 1)
        output.append(str(content_index[p]) + "*" + content[p] + "*" + str(score))

    return(output)


