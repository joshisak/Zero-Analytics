from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from project import topicrank, models
from django.http import HttpResponse
import os

def home(request):
    if request.method == 'POST':
        return render(request, 'index.html')
    return render(request, 'home.html')

def index(request):
    return render(request, 'index.html')

def about(request):
    return render(request, 'about.html')

def corporateprojects(request):
    info = models.Project.objects.filter(email= "sakshijoshi320@gmail.com")
    project = {}
    project["details"] = []
    for i in range(0,len(info)):
        name =  info[i].projectname
        typ = info[i].projecttype
        description =  info[i].description
        project["details"].append([(name,typ,description)])
    return render(request, "corporateprojects.html",project)

def projectarchives(request):
    return render(request, 'projectarchives.html')

def mentorship(request):
    return render(request, 'mentorship.html')

def datamining(request):
    return render(request, 'datamining.html')

def descriptiveanalytics(request):
    info = models.Project.objects.filter(email= "sakshijoshi320@gmail.com")
    info1 = models.UserProfile.objects.get(email= "sakshijoshi320@gmail.com")
    return render(request, 'descriptiveanalytics.html',{'info':info,'user':info1})

def predictiveanalytics(request):
    return render(request, 'predictiveanalytics.html')

def projects(request):
    return render(request, 'projects.html')

def projectupload(request):
    return render(request, 'projectupload.html')

def trainingvideos(request):
    return render(request, 'trainingvideos.html')

def blogsandarticles(request):
    return render(request, 'blogsandarticles.html')

def contributorprofile(request):
    return render(request, 'contributorprofile.html')

def loading(request):
    return (request,'loading.html')

def userprofile(request):
    info1 = models.UserProfile.objects.get(email= "sakshijoshi320@gmail.com")
    #files = 'repository/'
    if request.method == 'POST':
        user = models.UserProfile()
        user.firstname = request.POST['firstName']
        user.lastname = request.POST['lastName']
        user.description = request.POST['description']
        user.email = request.POST['email']
        user.address1 = request.POST['AddressLine1']
        user.address2 = request.POST['AddressLine2']
        user.city = request.POST['City']
        user.region = request.POST['Region']
        user.zipcode = request.POST['ZipCode']
        user.country = request.POST['Country']
        user.linkedln = request.POST['linkedln']
        user.github = request.POST['github']
        user.otherlink = request.POST['otherLink']
        user.resume = request.FILES['resume']
        if 'picture' in request.FILES:
            user.picture = request.POST['picture']
        else:
            user.picture = False
        user.save()
    return render(request, 'userprofile.html',{"user":info1})

def form(request):
    return render(request, 'form.html')

def topicranking(request):
    files = 'repository/'
    if request.method == 'POST' and request.FILES['myfile'] :  
        myfile = request.FILES['myfile']
        fs = FileSystemStorage(location=files)
        filename = fs.save(myfile.name, myfile)
        uploaded_file_url = fs.url(filename) 
        return render(request, 'topicranking.html',{'uploaded_file_url':uploaded_file_url})
    
    return render(request, 'topicranking.html',{'name': files})

def topicranking_result(request):
    context = {}
    keywords =request.COOKIES.get('keywords')
    #system =request.COOKIES.get('Search')
    files =request.COOKIES.get('myfile')
    #context['system'] = system
    context['keywords'] = keywords
    context['file'] = files
    y = topicrank.return_content(keywords,files)
    x = []
    context['zipper'] = []
    for i in range(0,len(y)):
        x = y[i].split('*')
        context['zipper'].append([(x[0],x[1],x[2])])

    #print(context)
    return render(request,'topicranking_result.html',context)

def signup(request):
    if request.user.is_authenticated:
        return redirect('index')
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect('index')
        else:
            return render(request, 'signup.html', {'form': form})
    else:
        form = UserCreationForm()
        return render(request, 'signup.html', {'form': form})

def login(request):
    if request.user.is_authenticated:
        return render(request, 'homepage.html')
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('/')
        else:
            form = AuthenticationForm(request.POST)
            return render(request, 'login.html', {'form': form})
    else:
        form = AuthenticationForm()
        return render(request, 'login.html', {'form': form})