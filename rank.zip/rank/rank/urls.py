"""rank URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import path
from project import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.home, name='home'),
    path('index.html',views.index, name='index'),
    path('loading/',views.loading, name='loading'),
    path('topicranking.html',views.topicranking, name='topicranking'),
    path('topicranking_result/',views.topicranking_result, name='topicranking_result'),
    path('login/', auth_views.LoginView.as_view(template_name="login.html"), name='login'),
    path('logout/', auth_views.LogoutView.as_view(template_name= 'login.html'), name='logout'),
    path('signup/', views.signup, name='signup'),
    path('about.html', views.about, name='about'),
    path('corporateprojects.html', views.corporateprojects, name='corporateprojects'),
    path('projectarchives.html', views.projectarchives, name='projectarchives'),
    path('mentorship.html', views.mentorship, name='mentorship'),
    path('datamining.html', views.datamining, name='datamining'),
    path('descriptiveanalytics.html', views.descriptiveanalytics, name='descriptiveanalytics'),
    path('predictiveanalytics.html', views.predictiveanalytics, name='predictiveanalytics'),
    path('projects.html', views.projects, name='projects'),
    path('trainingvideos.html', views.trainingvideos, name='trainingvideos'),
    path('blogsandarticles.html', views.blogsandarticles, name='blogsandarticles'),
    path('contributorprofile.html', views.contributorprofile, name='contributorprofile'),
    path('userprofile.html', views.userprofile, name='userprofile'),
    path('projectupload.html', views.projectupload, name='projectupload'),
    path('form.html',views.form,name='form'),

                  #path('form.html',views.form,name='form'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)